package com.example.projetapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.projetapp.ml.DiseaseDetection;
import com.example.projetapp.ml.DiseaseDetection;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class MainActivity extends AppCompatActivity {
    TextView result, classified, clickHere,demoTxt ;
    ImageView imageView;
    Button picture;
    int imageSize=224;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result=findViewById(R.id.result);
        imageView=findViewById(R.id.imageView);
        picture=findViewById(R.id.button);

        demoTxt=findViewById(R.id.demotext);
        clickHere=findViewById(R.id.click_here);
        classified=findViewById(R.id.classified);

        demoTxt.setVisibility(View.VISIBLE);
        clickHere.setVisibility(View.GONE);
        classified.setVisibility(View.GONE);
        result.setVisibility(View.GONE);
        picture.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                //lancer camera si vous avez permission (dans le fichier manifest.xml)
                if(checkSelfPermission(Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED){
                    Intent cameraIntent= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent,1);    }
                else{ //request camera permission if we dont'have
                    requestPermissions(new String[]{Manifest.permission.CAMERA},100);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            Bitmap image = (Bitmap) data.getExtras().get("String");
           int dimension = Math.min(4128, 3096);
            image = ThumbnailUtils.extractThumbnail(image, dimension, dimension);
            //mettre image a la place de l'imageview
            imageView.setImageBitmap(image);

            demoTxt.setVisibility(View.GONE);
            clickHere.setVisibility(View.VISIBLE);
            classified.setVisibility(View.VISIBLE);
            result.setVisibility(View.VISIBLE);

            image = Bitmap.createScaledBitmap(image, 4128, 3096, false);
         classifyimage(image);

        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    private void classifyimage( Bitmap image){
        try{
            //code java dans le model(fichier model)*
            DiseaseDetection model= DiseaseDetection.newInstance(getApplicationContext());
            //create input for reference
            // ajouter 2 ligne build.gradle
           TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{ 1,224,244,3}, DataType.FLOAT32);
            ByteBuffer byteBuffer=ByteBuffer.allocate(4 * imageSize * imageSize * 3);
            byteBuffer.order(ByteOrder.nativeOrder());
            //get id array of 224*224 pixele in image
            int[] intValue= new int[ imageSize * imageSize];
           image.getPixels(intValue,0,image.getWidth(),0,0,image.getWidth(),image.getHeight());

            //iterate over pixels and extract R, G,B values ,add to bytebufffer
            int pixel=0;
            for(int i=0;i<imageSize ;i++){
                for(int j=0;j<imageSize ;i++){
                    int val=intValue[pixel++]; //RGB
                   byteBuffer.putFloat(((val >> 16    )& 0xFF) * ( 1.f /225.f  ) );
                    byteBuffer.putFloat(((val >> 0   )& 0xFF) * ( 1.f /225.f  ) );
                    byteBuffer.putFloat(((val & 0xFF) * ( 1.f /225.f  ) ) );
             }
           }
            inputFeature0.loadBuffer(byteBuffer);

            //run model interface and get result
            DiseaseDetection.Outputs outputs = model.process(inputFeature0);
            TensorBuffer outputFeatures0 =outputs.getOutputFeature0AsTensorBuffer();


            float[] confidence = outputFeatures0.getFloatArray();

            //find the index of the class with the biggest confidence
            int maxPcs = 0;
            float maxConfidence =0;
            for(int i=0;i<confidence.length ;i++){
                if(confidence[i] >  maxConfidence ){
                    maxConfidence = confidence[i] ;
                    maxPcs=i;
                }
            }
            String[]  classes={ "Pomme _ Apple _ تفاح ","Banane _ Banana _ موز","Fraise _ Strawberry _ فراولة ","Orange _ Orange _ برتقال","Kiwi _ Kiwi _ كيوي","pomme de terre _  Potato  _ بطاطا","Tomate _ Tomato _ طماطم","Poivre _ Pepper _ فلفل","Oignon _ Onion _ بصل "};
            result.setText(classes[maxPcs]);
            result.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // recherche la classe dans l'internet
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/searche?q" +result.getText())));
                }
            });
            model.close();

        } catch (IOException e) {     }
    }}






