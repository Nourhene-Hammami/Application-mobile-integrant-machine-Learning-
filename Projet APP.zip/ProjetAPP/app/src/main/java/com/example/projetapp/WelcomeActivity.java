package com.example.projetapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.text.BreakIterator;

public class WelcomeActivity extends AppCompatActivity {
    Button btn_login;
    Button btn_register;
    BreakIterator inputEmail;
    BreakIterator inputName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_welcome);
        //Listening to button event
        btn_login=(Button)findViewById(R.id.id_login) ;
        btn_login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Starting a new Intent
                Intent nextScreen = new Intent(WelcomeActivity.this, LoginActivity.class);
                startActivity(nextScreen);
            }
        });

        //Listening to button event
        btn_register=(Button)findViewById(R.id.id_register) ;
        btn_register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Starting a new Intent
                Intent nextScreen = new Intent(WelcomeActivity.this, RegisterActivity.class);
                //Sending data to another Activity
               // nextScreen.putExtra("name", inputName.getText().toString());
                //nextScreen.putExtra("email", inputEmail.getText().toString());
                //Log.e("n", inputName.getText()+"."+ inputEmail.getText());
                startActivity(nextScreen);
            }
        });

    }
    }







