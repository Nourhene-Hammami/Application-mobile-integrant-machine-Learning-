package com.example.projetapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.BreakIterator;

public class RegisterActivity extends AppCompatActivity {
    //proprieté
    private ImageView imageView;
    private Button button ;
    EditText txtName,txtEmail;
Button btn_Add;
    TextView textInputLayoutPassword;
    TextView textInputLayoutUserName;
    TextView textInputLayoutEmail;

    BreakIterator editTextUserName ;
    BreakIterator editTextPassword ;
    BreakIterator editTextEmail ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        txtName = findViewById(R.id.name);
        txtEmail = findViewById(R.id.emailorphone);

    Intent i = getIntent();
    // Receiving the Data
    String name = i.getStringExtra("name");
    String emailorphone = i.getStringExtra("emailorphone");
    Log.e("RegisterActivity", name+ "."  +emailorphone);
// Displaying Received data
       txtName.setText(name);
       txtEmail.setText(emailorphone);

        //Listening to button event
        btn_Add =(Button)findViewById(R.id.ADD) ;
        btn_Add.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Starting a new Intent
                Intent nextScreen = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(nextScreen);
            }
        });
}
    //This method is used to validate input given by user
    public boolean validate() {
        boolean valid = false;
    //Get values from EditText fields
        String UserName = editTextUserName.getText().toString();
        String Email = editTextEmail.getText().toString();
        String Password = editTextPassword.getText().toString();

//Handling validation for UserName field

        if (UserName.isEmpty()) {
            valid = false;
            textInputLayoutUserName.setError("Please enter valid username!");
        } else {
            if (UserName.length() > 5) { valid = true;
                textInputLayoutUserName.setError(null);
            } else {
                valid = false;
                textInputLayoutUserName.setError("Username is to short!");
            }
        }
//Handling validation for Email field

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) { valid = false;
            textInputLayoutEmail.setError("Please enter valid email!");
        } else {
            valid = true; textInputLayoutEmail.setError(null);
        }

//Handling validation for Password field

        if (Password.isEmpty()) { valid = false;
            textInputLayoutPassword.setError("Please enter valid password!");
        } else {
            if (Password.length() > 5) { valid = true;
                textInputLayoutPassword.setError(null);
            } else {
                valid = false;
                textInputLayoutPassword.setError("Password is to short!");
            }
        }
        return valid;
    }


}
