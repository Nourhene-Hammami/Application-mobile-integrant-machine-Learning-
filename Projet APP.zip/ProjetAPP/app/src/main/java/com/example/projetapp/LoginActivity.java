package com.example.projetapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.BreakIterator;

public class LoginActivity extends AppCompatActivity {
    EditText inputEmail,inputName;
    Button btn_login;
    Button btnRegisterActivity;


    TextView textInputLayoutPassword;
    TextView textInputLayoutEmail;

    BreakIterator editTextPassword;
    BreakIterator editTextEmail;

    Button id_login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

    //Listening to button event
        btnRegisterActivity=(Button)findViewById(R.id.login) ;
       btnRegisterActivity.setOnClickListener(new View.OnClickListener() {

            public void onClick(View V) {
    //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), RegisterActivity.class);
    //Sending data to another Activity

               //nextScreen.putExtra("name", inputName.getText().toString());
                //nextScreen.putExtra("email", inputEmail.getText().toString());
                //Log.e("n", inputName.getText()+"."+ inputEmail.getText());
                startActivity(nextScreen);
            }
        });
    }

    //This method is used to validate input given by user
    public boolean validate() {
        boolean valid = false;
//Get values from EditText fields

        String Email = editTextEmail.getText().toString();

        String Password = editTextPassword.getText().toString();
//Handling validation for Email field

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) { valid = false;
            textInputLayoutEmail.setError("Please enter valid email!");
        } else {
            valid = true;
            textInputLayoutEmail.setError(null);
        }
//Handling validation for Password field

        if (Password.isEmpty()) { valid = false;
            textInputLayoutPassword.setError("Please enter valid password!");
        } else {
            if (Password.length() > 5) {

                valid = true;
                textInputLayoutPassword.setError(null);
            } else {
                valid = false;
                textInputLayoutPassword.setError("Password is to short!");
            }
        }
        return valid;
    }

}